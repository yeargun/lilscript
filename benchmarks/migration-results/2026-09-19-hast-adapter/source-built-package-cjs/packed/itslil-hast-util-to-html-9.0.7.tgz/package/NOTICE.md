# Notices

`@itslil/hast-util-to-html` is an independent LilScript reimplementation of
[`hast-util-to-html`](https://github.com/syntax-tree/hast-util-to-html). It is not affiliated with or
endorsed by the upstream authors.

Algorithms and public API names derive from that project, distributed under
the MIT license. The original license notice is preserved in [LICENSE](./LICENSE).

The LilScript compiler is developed separately at
[yeargun/lilscript](https://github.com/yeargun/lilscript).
