const vectors=[{"name": "complete", "ints": [], "strings": ["alpha:123;beta:45"], "expected": "6746\n"}, {"name": "spaces", "ints": [], "strings": ["item:9; next:802; tail:7"], "expected": "10056\n"}, {"name": "comment-stop", "ints": [], "strings": ["token:314#ignored:999"], "expected": "3646\n"}];
const source=vectors[Number(process.env.N2_VECTOR||0)],repeat=Number(process.env.N2_REPEAT||1),counted=false;
const input={ints:Array.from({length:source.ints.length*repeat},(_,i)=>source.ints[i%source.ints.length]),strings:counted?Array.from({length:source.strings.length*repeat},(_,i)=>source.strings[i%source.strings.length]):source.strings.map(x=>x.repeat(repeat))};
const trace=process.env.N2_TRACE!==undefined,events=[];
if(trace)process.once('exit',()=>process.stderr.write('LILSCRIPT_ALGORITHM_TRACE='+JSON.stringify(events)+'\n'));
globalThis.algorithmCount=()=>{if(trace)events.push(['count']);return Math.max(input.ints.length,input.strings.length)};
globalThis.algorithmInt=index=>{if(!Number.isInteger(index)||index<0||index>=input.ints.length)throw Error('int bounds');if(trace)events.push(['int',index]);return input.ints[index]};
globalThis.algorithmString=index=>{if(!Number.isInteger(index)||index<0||index>=input.strings.length)throw Error('string bounds');if(trace)events.push(['string',index]);return input.strings[index]};
require(process.argv[2]);
