const vectors=[{"name": "keywords", "ints": [], "strings": ["alpha", "beta", "gamma", "delta", "epsilon"], "expected": "dictionary-odd-three\n199\n"}, {"name": "prefixes", "ints": [], "strings": ["pre-load", "post-render", "internal-cache", "plain", "pre-save"], "expected": "dictionary-odd-two\n194\n"}, {"name": "mixed", "ints": [], "strings": ["gamma", "internal-node", "beta", "post-task", "unknown", "alpha"], "expected": "dictionary-even-zero\n240\n"}, {"name": "inherited-name", "ints": [], "strings": ["constructor"], "expected": "dictionary-odd-three\n15\n"}];
const source=vectors[Number(process.env.N2_VECTOR||0)],repeat=Number(process.env.N2_REPEAT||1),counted=true;
const input={ints:Array.from({length:source.ints.length*repeat},(_,i)=>source.ints[i%source.ints.length]),strings:counted?Array.from({length:source.strings.length*repeat},(_,i)=>source.strings[i%source.strings.length]):source.strings.map(x=>x.repeat(repeat))};
const trace=process.env.N2_TRACE!==undefined,events=[];
if(trace)process.once('exit',()=>process.stderr.write('LILSCRIPT_ALGORITHM_TRACE='+JSON.stringify(events)+'\n'));
globalThis.algorithmCount=()=>{if(trace)events.push(['count']);return Math.max(input.ints.length,input.strings.length)};
globalThis.algorithmInt=index=>{if(!Number.isInteger(index)||index<0||index>=input.ints.length)throw Error('int bounds');if(trace)events.push(['int',index]);return input.ints[index]};
globalThis.algorithmString=index=>{if(!Number.isInteger(index)||index<0||index>=input.strings.length)throw Error('string bounds');if(trace)events.push(['string',index]);return input.strings[index]};
require(process.argv[2]);
