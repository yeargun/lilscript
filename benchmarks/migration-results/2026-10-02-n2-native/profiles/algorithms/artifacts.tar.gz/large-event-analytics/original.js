(() => {
  // comparison/algorithms/cases/large-event-analytics/normalize.js
  function absoluteValue(value) {
    return value < 0 ? -value | 0 : value;
  }
  function clampMagnitude(value) {
    return value > 500 ? 500 : value;
  }
  function normalizedMagnitude(value) {
    return clampMagnitude(absoluteValue(value));
  }
  function scaleMagnitude(value, factor) {
    return normalizedMagnitude(value) * factor | 0;
  }

  // comparison/algorithms/cases/large-event-analytics/classify.js
  function prefixClass(token) {
    return token.startsWith("cache:") ? 11 : token.startsWith("view:") ? 17 : token.startsWith("data:") ? 23 : 3;
  }
  function suffixClass(token) {
    return token.endsWith(":hot") ? 13 : token.endsWith(":cold") ? -5 : token.endsWith(":idle") ? 7 : 1;
  }
  function keywordClass(token) {
    return token === "render" ? 29 : token === "hydrate" ? 31 : token === "commit" ? 37 : token === "invalidate" ? 41 : 5;
  }
  function tokenClass(token) {
    return (prefixClass(token) * 3 | 0) + (suffixClass(token) * 5 | 0) + keywordClass(token) | 0;
  }

  // comparison/algorithms/cases/large-event-analytics/score.js
  function mixIndex(index) {
    return (index + 3) * 11 | 0;
  }
  function weightedMagnitude(value, index) {
    return scaleMagnitude(value, index % 4 + 1);
  }
  function routeWeight(token) {
    return tokenClass(token) * 13 | 0;
  }
  function eventScore(value, token, index) {
    return weightedMagnitude(value, index) + routeWeight(token) + mixIndex(index) | 0;
  }

  // comparison/algorithms/cases/large-event-analytics/aggregate.js
  function beginAggregate(first) {
    return { _total: first, _high: first, _low: first, _count: 1, _fingerprint: first ^ 97 };
  }
  function updateAggregate(stats, score, index) {
    return {
      _total: stats._total + score | 0,
      _high: score > stats._high ? score : stats._high,
      _low: score < stats._low ? score : stats._low,
      _count: stats._count + 1 | 0,
      _fingerprint: (stats._fingerprint * 33 | 0) ^ score + (index * 7 | 0)
    };
  }
  function checksumAggregate(stats) {
    return stats._fingerprint ^ (stats._high * 17 | 0) + (stats._low * 11 | 0) + (stats._count * 5 | 0);
  }
  function finishAggregate(stats) {
    return stats._total + checksumAggregate(stats) | 0;
  }

  // comparison/algorithms/cases/large-event-analytics/pipeline.js
  function processEvents() {
    const first = eventScore(algorithmInt(0), algorithmString(0), 0);
    let stats = beginAggregate(first);
    const count = algorithmCount();
    for (let index = 1; index < count; index++) {
      stats = updateAggregate(
        stats,
        eventScore(algorithmInt(index), algorithmString(index), index),
        index
      );
    }
    return stats;
  }
  function summaryLabel(stats) {
    const spread = stats._high - stats._low | 0;
    if (spread > 500) return "analytics-wide";
    if (stats._total < 0) return "analytics-negative";
    if (stats._count >= 6) return "analytics-batch";
    return "analytics-compact";
  }
  function renderResult(stats) {
    console.log(summaryLabel(stats));
    return finishAggregate(stats);
  }

  // comparison/algorithms/cases/large-event-analytics/main.js
  function runEventAnalytics() {
    return renderResult(processEvents());
  }
  console.log(runEventAnalytics());
})();
