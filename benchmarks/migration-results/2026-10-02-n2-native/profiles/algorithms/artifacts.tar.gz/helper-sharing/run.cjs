const vectors=[{"name": "short", "ints": [2, 4, 6, 8], "strings": [], "expected": "-68\n"}, {"name": "signed", "ints": [-5, 9, -2, 14, 3, -8], "strings": [], "expected": "-487\n"}, {"name": "sequence", "ints": [1, 1, 2, 3, 5, 8, 13, 21], "strings": [], "expected": "-806\n"}, {"name": "i32-extrema", "ints": [2147483647, -2147483648], "strings": [], "expected": "141\n"}];
const source=vectors[Number(process.env.N2_VECTOR||0)],repeat=Number(process.env.N2_REPEAT||1),counted=true;
const input={ints:Array.from({length:source.ints.length*repeat},(_,i)=>source.ints[i%source.ints.length]),strings:counted?Array.from({length:source.strings.length*repeat},(_,i)=>source.strings[i%source.strings.length]):source.strings.map(x=>x.repeat(repeat))};
const trace=process.env.N2_TRACE!==undefined,events=[];
if(trace)process.once('exit',()=>process.stderr.write('LILSCRIPT_ALGORITHM_TRACE='+JSON.stringify(events)+'\n'));
globalThis.algorithmCount=()=>{if(trace)events.push(['count']);return Math.max(input.ints.length,input.strings.length)};
globalThis.algorithmInt=index=>{if(!Number.isInteger(index)||index<0||index>=input.ints.length)throw Error('int bounds');if(trace)events.push(['int',index]);return input.ints[index]};
globalThis.algorithmString=index=>{if(!Number.isInteger(index)||index<0||index>=input.strings.length)throw Error('string bounds');if(trace)events.push(['string',index]);return input.strings[index]};
require(process.argv[2]);
