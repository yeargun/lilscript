const vectors=[{"name": "retail", "ints": [120, 2, 10, 18, 75, 4, 0, 8, 310, 1, 25, 20], "strings": [], "expected": "8991\n"}, {"name": "discount-bounds", "ints": [50, 3, -4, 10, 200, 2, 99, 15, 99, 5, 40, 0], "strings": [], "expected": "2751\n"}, {"name": "signed-tax", "ints": [180, 1, 12, -5, 33, 7, 5, 21, 400, 2, 50, 9, 12, 9, 0, 4], "strings": [], "expected": "5412\n"}, {"name": "discount-overflow", "ints": [1073741824, 1, 50, 0], "strings": [], "expected": "-1030792150\n"}, {"name": "tax-overflow", "ints": [1073741824, 1, 0, 50], "strings": [], "expected": "-838064458\n"}];
const source=vectors[Number(process.env.N2_VECTOR||0)],repeat=Number(process.env.N2_REPEAT||1),counted=true;
const input={ints:Array.from({length:source.ints.length*repeat},(_,i)=>source.ints[i%source.ints.length]),strings:counted?Array.from({length:source.strings.length*repeat},(_,i)=>source.strings[i%source.strings.length]):source.strings.map(x=>x.repeat(repeat))};
const trace=process.env.N2_TRACE!==undefined,events=[];
if(trace)process.once('exit',()=>process.stderr.write('LILSCRIPT_ALGORITHM_TRACE='+JSON.stringify(events)+'\n'));
globalThis.algorithmCount=()=>{if(trace)events.push(['count']);return Math.max(input.ints.length,input.strings.length)};
globalThis.algorithmInt=index=>{if(!Number.isInteger(index)||index<0||index>=input.ints.length)throw Error('int bounds');if(trace)events.push(['int',index]);return input.ints[index]};
globalThis.algorithmString=index=>{if(!Number.isInteger(index)||index<0||index>=input.strings.length)throw Error('string bounds');if(trace)events.push(['string',index]);return input.strings[index]};
require(process.argv[2]);
