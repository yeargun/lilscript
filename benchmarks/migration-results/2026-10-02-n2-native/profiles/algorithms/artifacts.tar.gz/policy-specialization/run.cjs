const vectors=[{"name": "mixed", "ints": [0, 12, 5, 1, -9, 90, 2, 33, 44, 3, -7, -1], "strings": [], "expected": "368\n"}, {"name": "clamped", "ints": [0, 200, 100, 1, -180, 20, 2, 150, 70, 3, -200, 82], "strings": [], "expected": "2068\n"}, {"name": "bands", "ints": [0, 5, -2, 1, 5, 0, 2, 5, 41, 3, 5, 81, 2, -5, 80], "strings": [], "expected": "99\n"}];
const source=vectors[Number(process.env.N2_VECTOR||0)],repeat=Number(process.env.N2_REPEAT||1),counted=true;
const input={ints:Array.from({length:source.ints.length*repeat},(_,i)=>source.ints[i%source.ints.length]),strings:counted?Array.from({length:source.strings.length*repeat},(_,i)=>source.strings[i%source.strings.length]):source.strings.map(x=>x.repeat(repeat))};
const trace=process.env.N2_TRACE!==undefined,events=[];
if(trace)process.once('exit',()=>process.stderr.write('LILSCRIPT_ALGORITHM_TRACE='+JSON.stringify(events)+'\n'));
globalThis.algorithmCount=()=>{if(trace)events.push(['count']);return Math.max(input.ints.length,input.strings.length)};
globalThis.algorithmInt=index=>{if(!Number.isInteger(index)||index<0||index>=input.ints.length)throw Error('int bounds');if(trace)events.push(['int',index]);return input.ints[index]};
globalThis.algorithmString=index=>{if(!Number.isInteger(index)||index<0||index>=input.strings.length)throw Error('string bounds');if(trace)events.push(['string',index]);return input.strings[index]};
require(process.argv[2]);
