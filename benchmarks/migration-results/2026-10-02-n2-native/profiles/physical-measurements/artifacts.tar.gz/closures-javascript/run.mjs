globalThis.profileIterations=()=>Number(process.env.LILSCRIPT_N2_ITERATIONS)|0;await import("/tmp/lilscript-n2-physical-measure-2/closures-javascript/profile.mjs");
