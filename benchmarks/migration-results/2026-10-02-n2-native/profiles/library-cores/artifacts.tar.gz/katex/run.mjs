globalThis.profileIterations=()=>Number(process.env.LILSCRIPT_N2_ITERATIONS)|0;await import("/tmp/lilscript-n2-cores-3/katex/profile.mjs");
